#!/usr/bin/env python

import pandas
data = pandas.read_csv('data/NENE01812A.csv')
plt = data.plot()
figure = plt.get_figure()
figure.savefig('plots/NENE01812A.pdf')

with open('results/max.txt', 'w') as file:
    file.write(str(data.max()))
    file.close()


